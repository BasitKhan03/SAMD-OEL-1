package com.example.oel1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        EditText username=findViewById(R.id.email);
        EditText password=findViewById(R.id.password);
        Button btn_login = findViewById(R.id.btn_login);
        TextView btn_sign = findViewById(R.id.btn_signup);

        btn_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(username.getText().toString().equals("xyz@gmail.com") && password.getText().toString().equals("abc123")){

                    startActivity(new Intent(MainActivity.this, DashboardActivity.class));
                }

                else
                {
                    Toast.makeText(getApplicationContext(),"Invalid Login Details...",Toast.LENGTH_SHORT).show();
                }
            }
        });

        btn_sign.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this, RegistrationActivity.class));
            }
        });


    }
}