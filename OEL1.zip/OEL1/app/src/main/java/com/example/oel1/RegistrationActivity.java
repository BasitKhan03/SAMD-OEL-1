package com.example.oel1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.content.Intent;

public class RegistrationActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);

        EditText username=findViewById(R.id.email);
        EditText passwordd=findViewById(R.id.password);
        TextView btn2signup=findViewById(R.id.btn_signup);
        Button btn1login=findViewById(R.id.btn_login);

        btn1login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(RegistrationActivity.this, MainActivity.class));
            }
        });

        btn2signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String email = username.getText().toString().trim();
                String password= passwordd.getText().toString().trim();

                if(email.isEmpty())
                {
                    username.setError("Email is empty");
                    username.requestFocus();
                    return;
                }

                else if(password.isEmpty())
                {
                    passwordd.setError("Enter the password");
                    passwordd.requestFocus();
                    return;
                }

                else if(password.length()<5)
                {
                    passwordd.setError("Length of the password should be more than 5");
                    passwordd.requestFocus();
                    return;
                }

                else
                {
                    Toast.makeText(getApplicationContext(),"You are successfully Registered",Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}